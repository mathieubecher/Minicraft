#ifndef __GUI_H__
#define __GUI_H__

#define GUI_MLBUTTON 0x0001
#define GUI_MRBUTTON 0x0002
#define GUI_MMBUTTON 0x0004

#define GUI_KEY_BACK 0x0008
#define GUI_KEY_DELETE 0x007f

#endif